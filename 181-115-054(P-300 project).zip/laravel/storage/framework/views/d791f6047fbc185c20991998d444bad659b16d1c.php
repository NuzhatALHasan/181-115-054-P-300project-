

<?php $__env->startSection('content'); ?>

<div>
	<body style ="background-color:orange">

		
	</body>

	<h1 style="color:green" align="center"> Worker Profiles </h1>


	<br>
	<a href="<?php echo e(route('workers.create')); ?>"> Register Worker </a>

	<br>
	<br>

	<table border="4" width="1200" align="center">
		<align="center">
		<tr>
			<th style="font-size:20" align="center"> Worker ID </th>
			<th style="font-size:20" align="center"> Full Name </th>
			<th style="font-size:20" align="center"> Shift </th>
			<th style="font-size:20" align="center"> Worker Post </th>
			<th style="font-size:20" align="center"> Worker Salary </th>
			<th style="font-size:20" align="center"> Action </th>
		</tr>

		<?php $__currentLoopData = $workers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $worker): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr> 
			<td align="center"><?php echo e($worker->worker_id); ?> </td>
			<td align="center"><?php echo e($worker->name); ?> </td>
			<td align="center"><?php echo e($worker->shift); ?> </td>
			<td align="center"><?php echo e($worker->worker_post); ?> </td>
			<td align="center"><?php echo e($worker->worker_salary); ?> </td>
			<td>
				<form action="<?php echo e(route('workers.destroy', $worker->id)); ?>" method="POST" align="center">
					<a href="<?php echo e(route('workers.edit', $worker->id)); ?>" align="center"> Edit </a>					
					<?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?> 

					<button type="submit" align="center" > Delete </button>
				</form>
			</td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 

	</table>

</div>
<?php echo $__env->make('workers.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\resources\views/workers/index.blade.php ENDPATH**/ ?>