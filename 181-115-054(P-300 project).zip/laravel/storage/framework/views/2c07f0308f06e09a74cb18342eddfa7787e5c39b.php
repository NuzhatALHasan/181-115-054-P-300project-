

<?php $__env->startSection('content'); ?>
<?php if($errors->any()): ?>
    <div  >
        <strong>Whoops!</strong> There were some problems with your input.<br><br>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<div>
	<form action="<?php echo e(route('workers.store')); ?>" method="POST" align="center">
 	 	<?php echo csrf_field(); ?>
 	 	
		 <input type="text" name="worker_id" placeholder="Worker ID" align="center"> 
		<br>
		 <input type="text" name="name" placeholder="Full Name" align="center">
		<br>
        <input type="text" name="shift" placeholder="Shift" align="center">
		  <br>
        <input type="text" name="worker_post" placeholder="Worker Post" align="center">
		  <br>
		  <input type="text" name="worker_salary" placeholder="Worker Salary" align="center">

         <br><br>
		<button type="submit" align="center" >Register</button>

		


	</form>

</div>
<?php echo $__env->make('workers.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\resources\views/workers/create.blade.php ENDPATH**/ ?>