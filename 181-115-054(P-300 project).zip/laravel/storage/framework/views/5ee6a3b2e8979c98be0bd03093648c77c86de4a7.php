

<?php $__env->startSection('content'); ?>

<div>
	<body style ="background-color:FFE042">

		
	</body>

	<h1 style="color:green",'size:40'> Worker Profiles </h1>


	<br>
	<a href="<?php echo e(route('Workers.create')); ?>"> Register Worker </a>

	<br>
	<br>

	<table border="4" width="1200">
		<align="center">
		<tr>
			<th style="font-size:20"> Student ID </th>
			<th style="font-size:20"> Full Name </th>
			<th style="font-size:20"> Batch </th>
			<th style="font-size:20"> Action </th>
		</tr>

		<?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr> 
			<td><?php echo e($student->student_id); ?> </td>
			<td><?php echo e($student->name); ?> </td>
			<td><?php echo e($student->batch); ?> </td>
			<td>
				<form action="<?php echo e(route('students.destroy', $student->id)); ?>" method="POST">
					<a href="<?php echo e(route('students.edit', $student->id)); ?>" > Edit </a>					
					<?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?> 

					<button type="submit" > Delete </button>
				</form>
			</td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 

	</table>

</div>
<?php echo $__env->make('students.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\resources\views/students/index.blade.php ENDPATH**/ ?>