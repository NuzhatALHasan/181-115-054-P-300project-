<?php

echo '<h1>Laravel 8<h1>'; ?><?php /**PATH C:\xampp\htdocs\laravel\resources\views/welcome.blade.php ENDPATH**/ ?>