

<?php $__env->startSection('content'); ?>
<?php if($errors->any()): ?>
    <div  >
        <strong>Whoops!</strong> There were some problems with your input.<br><br>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
 
<div>
	<form action="<?php echo e(route('students.update',$student->id)); ?>" method="POST">
 	 	<?php echo csrf_field(); ?>
 	 	<?php echo method_field('PUT'); ?>
 	 	
		Student ID:<input type="text" name="student_id" placeholder="Student ID (XXX-XXX-XXX)" value="<?php echo e($student->student_id); ?>"> 
		<br>
		Student Name:<input type="text" name="name" placeholder="Full Name"
		 value="<?php echo e($student->name); ?>">
		<br>

		Student Batch: <input type="text" name="batch" placeholder="Batch" value="<?php echo e($student->batch); ?>">
	
		<br> <br>
		<button type="submit" >Update</button>

		


	</form>

</div>
<?php echo $__env->make('students.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\resources\views/students/edit.blade.php ENDPATH**/ ?>