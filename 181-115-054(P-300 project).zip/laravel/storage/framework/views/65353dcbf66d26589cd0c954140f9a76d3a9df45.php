
<html>
<head> 
	<title> CSE 300: Project 300 Laravel Project</title>
</head>
<body>
	<div class="container"> 
		<?php echo $__env->yieldContent('content'); ?>
	</div>

</body>
</html><?php /**PATH C:\xampp\htdocs\laravel\resources\views/workers/layout.blade.php ENDPATH**/ ?>