@extends('workers.layout')

@section('content')

<div>
	<body style ="background-color:orange">

		
	</body>

	<h1 style="color:green" align="center"> Worker Profiles </h1>


	<br>
	<a href="{{ route('workers.create') }}"> Register Worker </a>

	<br>
	<br>

	<table border="4" width="1200" align="center">
		<align="center">
		<tr>
			<th style="font-size:20" align="center"> Worker ID </th>
			<th style="font-size:20" align="center"> Full Name </th>
			<th style="font-size:20" align="center"> Shift </th>
			<th style="font-size:20" align="center"> Worker Post </th>
			<th style="font-size:20" align="center"> Worker Salary </th>
			<th style="font-size:20" align="center"> Action </th>
		</tr>

		@foreach ($workers as $worker)
		<tr> 
			<td align="center">{{$worker->worker_id}} </td>
			<td align="center">{{$worker->name}} </td>
			<td align="center">{{$worker->shift}} </td>
			<td align="center">{{$worker->worker_post}} </td>
			<td align="center">{{$worker->worker_salary}} </td>
			<td>
				<form action="{{ route('workers.destroy', $worker->id)}}" method="POST" align="center">
					<a href="{{ route('workers.edit', $worker->id)}}" align="center"> Edit </a>					
					@csrf
                    @method('DELETE') 

					<button type="submit" align="center" > Delete </button>
				</form>
			</td>
		</tr>
		@endforeach 

	</table>

</div>