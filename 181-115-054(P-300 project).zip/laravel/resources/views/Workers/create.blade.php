@extends('workers.layout')

@section('content')
@if ($errors->any())
    <div  >
        <strong>Whoops!</strong> There were some problems with your input.<br><br>
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif

<div>
	<form action="{{route('workers.store')}}" method="POST" align="center">
 	 	@csrf
 	 	
		 <input type="text" name="worker_id" placeholder="Worker ID" align="center"> 
		<br>
		 <input type="text" name="name" placeholder="Full Name" align="center">
		<br>
        <input type="text" name="shift" placeholder="Shift" align="center">
		  <br>
        <input type="text" name="worker_post" placeholder="Worker Post" align="center">
		  <br>
		  <input type="text" name="worker_salary" placeholder="Worker Salary" align="center">

         <br><br>
		<button type="submit" align="center" >Register</button>

		


	</form>

</div>