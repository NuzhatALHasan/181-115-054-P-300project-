@extends('workers.layout')

@section('content')
@if ($errors->any())
    <div  >
        <strong>Whoops!</strong> There were some problems with your input.<br><br>
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif
 
<div>
	<form action="{{route('workers.update',$worker->id) }}" method="POST" align="center">
 	 	@csrf
 	 	@method('PUT')
 	 	
		 ID:<input type="text" name="worker_id" placeholder="Worker ID" value="{{$worker->worker_id}}" align="center"> 
		<br>
		 Name:<input type="text" name="name" placeholder="Full Name"
		 value="{{$worker->name}}" align="center">
		<br>

		Shift: <input type="text" name="shift" placeholder="Shift" value="{{$worker->batch}}" align="center">
		<br>
		Worker_Post:<input type="text" name="worker_post" placeholder="Worker Post" value="{{$worker->worker_post}}" align="center"> 
		<br>
		Worker_Salary:<input type="text" name="worker_salary" placeholder="Worker Salary" value="{{$worker->worker_salary}}" align="center">
	
		<br> <br>
		<button type="submit" align="center" >Update</button>

		



	</form>

</div>