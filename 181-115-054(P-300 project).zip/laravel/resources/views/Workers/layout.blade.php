
<html>
<head> 
	<title> CSE 300: Project 300 Laravel Project</title>
</head>
<body>
	<div class="container"> 
		@yield('content')
	</div>

</body>
</html>