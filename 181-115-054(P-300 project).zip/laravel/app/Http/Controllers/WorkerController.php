<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Worker;

class WorkerController extends Controller
{
   public function index(){
		$workers = Worker::latest()->paginate(5);

		return view('workers.index', compact('workers'));
	}

	 public function create(){

    	return view('workers.create');
    }

    public function store(Request $request){
    	$request->validate([
    		'name'=>'required',
    		'worker_id' => 'required',
    		'shift'=>'required',
            'worker_post'=>'required',
            'worker_salary'=>'required'
    	]);

    	Worker::create($request->all());

    	return redirect()->route('workers.index')->with('success', 'Profile Created Successflly!');
    }

    public function edit(Worker $worker){
 		return view('workers.edit', compact('worker'));
 	}


 	public function update(Request $request, Worker $worker){
 		$request->validate([
    		'name'=>'required',
    		'worker_id' => 'required',
    		'shift'=>'required',
            'worker_post'=>'required',
            'worker_salary'=>'required'
    	]);

 		
    	$worker->update($request->all());

    	return redirect()->route('workers.index')->with('success', 'Profile Updated Successflly!');
 	}

 	public function destroy(Worker $worker){

 		$worker->delete();
 		return redirect()->route('workers.index')->with('success', 'Profile Deleted Successflly!');
 	}
}
